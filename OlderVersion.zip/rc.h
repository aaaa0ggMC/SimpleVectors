#ifndef RC_H_INCLUDED
#define RC_H_INCLUDED

#define MAIN_ICON 1234

#endif // RC_H_INCLUDED
