#ifndef RES_H_INCLUDED
#define RES_H_INCLUDED

#define MAIN_ICON 1234

#define TRANSLATE_PATH "data"
#define CONFIG_PATH "data/config.cfg"

#endif // RES_H_INCLUDED
